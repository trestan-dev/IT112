<!DOCTYPE html>
<html>
<head><title>Edit Student</title></head>
<body>
    <h2>Edit Student</h2>
    <form method="post" action="<?php echo site_url('student/update/'.$student->id);?>">
        <input type="number" name="student_no" value="<?php echo $student->student_no; ?>">
        <br><br><input type="text" name="first_name" value="<?php echo $student->first_name; ?>">
        <br><br><input type="text" name="last_name" value="<?php echo $student->last_name; ?>">
        <br><br><input type="text" name="course" value="<?php echo $student->course; ?>">
        <br><br><input type="submit" value="Update Student">
    </form>
</body>
</html>