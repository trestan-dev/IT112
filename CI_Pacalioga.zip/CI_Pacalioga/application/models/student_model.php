<?php 
    class student_model extends CI_Model {
        public function insert_student($data) {
            return $this->db->insert('student',$data);
        }

        public function get_students(){
            return $this->db->get('student')->result();
        }

        public function get_student($id){
            return $this->db->get_where('student',['id' => $id])->row();
        }

        public function update_student($id, $data){
            return $this->db->where('id', $id)->update('student', $data);
        }

        public function delete_student($id) {
            $this->db->where('id', $id);
            return $this->db->delete('student');
        }
    }
?>